﻿// *******************************************************************************************
/// <summary>
/// 
/// </summary>
/// <created>ʆϒʅ,03.10.2019</created>
/// <changed>ʆϒʅ,03.10.2019</changed>
// *******************************************************************************************

#ifndef GTESTSCLASS_H
#define GTESTSCLASS_H


#include <gtest/gtest.h>
#include "../libStyle/style.h"
#include "../libMainWindow/mainwindow.h"


class QtAppTest : public testing::Test
{


};


#endif // !GTESTSCLASS_H
